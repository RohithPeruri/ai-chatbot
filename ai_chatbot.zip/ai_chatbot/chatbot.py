import json
import random

with open("responses.json", "r") as file:
    responses = json.load(file)

def get_response(user_input):
    user_input = user_input.lower()

    for intent in responses:
        for pattern in intent["patterns"]:
            if pattern.lower() in user_input:
                return random.choice(intent["responses"])

    return "Sorry, I don't understand that. Please try another question."