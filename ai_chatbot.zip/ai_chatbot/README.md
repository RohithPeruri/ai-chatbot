# AI Chatbot Web Application

## Technologies Used
- Python
- Flask
- HTML
- CSS
- JSON

## Features
- Welcome Page
- Chat Interface
- User Input
- AI Responses
- Flask Backend
- Dynamic Chat Display

## Run Project

Install Flask:

pip install -r requirements.txt

Run:

python app.py

Open Browser:

http://127.0.0.1:5000